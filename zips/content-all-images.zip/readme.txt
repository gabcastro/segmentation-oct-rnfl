contém todas as imagens, menos aquelas que considerei 
contexto 4 (muito ruído)