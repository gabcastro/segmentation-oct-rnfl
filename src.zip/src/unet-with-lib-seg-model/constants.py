ROOT_DATA_DIR = '../data/data-L2/'

TRAIN_DIR = f'{ROOT_DATA_DIR}train'
TRAIN_ANNOTATION_DIR = f'{ROOT_DATA_DIR}train_annotation'

VAL_DIR = f'{ROOT_DATA_DIR}validation'
VAL_ANNOTATION_DIR = f'{ROOT_DATA_DIR}validation_annotation'

TEST_DIR = f'{ROOT_DATA_DIR}test'
TEST_ANNOTATION_DIR = f'{ROOT_DATA_DIR}test_annotation'