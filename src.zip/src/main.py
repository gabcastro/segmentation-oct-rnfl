from unet import Unet
from compile import Compile
from datagenerator import DataGenerator
import tensorflow as tf

def main():
    data_gen_args = dict(
        width_shift_range=0.05,
        height_shift_range=0.05,
        shear_range=0.1,
        zoom_range=[0.7,1],
        horizontal_flip=True,
        fill_mode='nearest'
    )

    datagen = DataGenerator(data_gen_args=data_gen_args,
                            directory='../data/data-gen/train',
                            folders=['grays', 'masks', 'augmentations'])
    transformation = datagen()
    
    input = tf.keras.Input(shape=(512, 512, 1))

    unet = Unet()
    unet(input)
    unet.summary()

    print('total trainable weights from unet: ', len(unet.trainable_weights))
    
    compile_methods = Compile()

    unet.compile(
        optimizer=compile_methods.optimizer,
        loss=compile_methods.loss,
        metrics=compile_methods.all_metrics
    )

    # history = unet.fit(
    #     x=trasnformations,
    #     steps_per_epoch=100,
    #     batch_size=8,
    #     epochs=15,
    #     verbose=1
    # )

if __name__ == "__main__":
    main()